package com.enteben19005324.opsc7311_task2_19005324;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class goals extends AppCompatActivity {

    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference("GOALS");

    EditText txt_exercise, txt_goalweight;
    Button save;

    GoalClass goalclass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goals);


        txt_exercise = findViewById(R.id.txt_exercise);
        txt_goalweight = findViewById(R.id.txt_goalweight);
        save = findViewById(R.id.btn_save3);


        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String exercise = txt_exercise.getText().toString().trim();
                String weight = txt_goalweight.getText().toString().trim();

                goalclass = new GoalClass(exercise, weight);
                myRef.setValue(goalclass);

            }
        });
    }
}