package com.enteben19005324.opsc7311_task2_19005324;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class registration extends AppCompatActivity {
    private Button button;

    EditText email, password;
    Button register;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);



        mAuth = FirebaseAuth.getInstance();

        email = findViewById(R.id.txt_email2);
        password = findViewById(R.id.txt_password2);
        register = findViewById(R.id.btn_register3);


        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String InsertEmail = email.getText().toString().trim();
                String InsertPassword = email.getText().toString().trim();
                mAuth.createUserWithEmailAndPassword(InsertEmail, InsertPassword)
                        .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    Toast.makeText(registration.this, "USER " + mAuth.getCurrentUser().getEmail() + " HAS BEEN REGISTERED!",
                                            Toast.LENGTH_SHORT).show();
                                } else {
                                    Toast.makeText(registration.this, "Something went wrong, Unable to register", Toast.LENGTH_SHORT).show();
                                }
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(registration.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });

    }
}