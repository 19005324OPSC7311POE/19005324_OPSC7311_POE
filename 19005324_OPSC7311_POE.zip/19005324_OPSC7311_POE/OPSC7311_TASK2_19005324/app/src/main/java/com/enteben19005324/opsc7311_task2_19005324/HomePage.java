package com.enteben19005324.opsc7311_task2_19005324;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class HomePage extends AppCompatActivity {
    private Button button2;
    private Button Daily;
    private Button Goals;
    private Button Graph;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_page);

        button2 = (Button) findViewById(R.id.btn_profile);
        Daily = (Button) findViewById(R.id.btn_daily);
        Goals = (Button) findViewById(R.id.btn_goals);
        Graph = (Button) findViewById(R.id.btn_graph);


        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openProfile();
            }
        });
        Daily.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openDailyReport();
            }
        });
        Goals.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openGoals();
            }
        });
        Graph.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openGraph();
            }
        });
    }

    public void openProfile() {
        Intent intent = new Intent(this, Profile.class);
        startActivity(intent);
    }

    public void openDailyReport() {
        Intent intent = new Intent(this, DailyReport.class);
        startActivity(intent);
    }

    public void openGoals() {
        Intent intent = new Intent(this, goals.class);
        startActivity(intent);
    }

    public void openGraph() {
        Intent intent = new Intent(this, Graph.class);
        startActivity(intent);
    }

    }
