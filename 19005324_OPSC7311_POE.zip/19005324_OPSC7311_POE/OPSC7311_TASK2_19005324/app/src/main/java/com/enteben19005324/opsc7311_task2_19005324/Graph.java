package com.enteben19005324.opsc7311_task2_19005324;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.anychart.AnyChart;
import com.anychart.AnyChartView;
import com.anychart.chart.common.dataentry.DataEntry;
import com.anychart.chart.common.dataentry.ValueDataEntry;
import com.anychart.charts.Cartesian;
import com.anychart.core.cartesian.series.Column;
import com.anychart.enums.Anchor;
import com.anychart.enums.HoverMode;
import com.anychart.enums.Position;
import com.anychart.enums.TooltipPositionMode;

import java.util.ArrayList;
import java.util.List;

public class Graph extends AppCompatActivity {

    public class ColumnChartActivity extends AppCompatActivity {

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_graph);

// FINDING CHART FROM THE DESIGN VIEW
            AnyChartView anyChartView = findViewById(R.id.any_chart_view);
            //anyChartView.setProgressBar(findViewById(R.id.progress_bar));

            Cartesian cartesian = AnyChart.column();

// VARIABLES GIVEN FROM THE USERS INPUT
            List<DataEntry> data = new ArrayList<>();
            data.add(new ValueDataEntry("Weight", 76));
            data.add(new ValueDataEntry("Calories", 558));
            data.add(new ValueDataEntry("Height", 177));
            data.add(new ValueDataEntry("Weight Lost", 5));
            data.add(new ValueDataEntry("Exercise per day (mins)",55 ));

            Column column = cartesian.column(data);

            column.tooltip()
                    .titleFormat("{%X}")
                    .position(Position.CENTER_BOTTOM)
                    .anchor(Anchor.CENTER_BOTTOM)
                    .offsetX(0d)
                    .offsetY(5d)
                    .format("${%Value}{groupsSeparator: }");

// BAR GRAPH NAME PLACED AT THE TOP OF THE GRAPH
            cartesian.animation(true);
            cartesian.title("FAT2fit Bar Graph");

            cartesian.yScale().minimum(0d);

            cartesian.yAxis(0).labels().format("${%Value}{groupsSeparator: }");

            cartesian.tooltip().positionMode(TooltipPositionMode.POINT);
            cartesian.interactivity().hoverMode(HoverMode.BY_X);

            cartesian.xAxis(0).title("WORKOUT (BODY)");
            cartesian.yAxis(0).title("NUMERIALS");

            anyChartView.setChart(cartesian);
        }
    }
}