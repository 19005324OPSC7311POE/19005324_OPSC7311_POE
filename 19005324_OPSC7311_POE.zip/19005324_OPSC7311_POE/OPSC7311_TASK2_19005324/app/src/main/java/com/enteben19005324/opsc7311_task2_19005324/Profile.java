package com.enteben19005324.opsc7311_task2_19005324;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Profile extends AppCompatActivity {
    private Button Update;

    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference myRef = database.getReference("PROFILE");


    EditText txt_name, txt_surname, txt_email5, txt_height, txt_weight;
    Button save;


    ProfileClass profileclass;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        Update = (Button) findViewById(R.id.btn_update);

        Update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openUpdateProfile();
            }
        });

        txt_name = findViewById(R.id.txt_name);
        txt_email5 = findViewById(R.id.txt_email5);
        txt_height = findViewById(R.id.txt_height);
        txt_weight = findViewById(R.id.txt_weight);
        save = findViewById(R.id.btn_save);


        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {

                String name = txt_name.getText().toString().trim();
                String surname = txt_surname.getText().toString().trim();
                String email = txt_email5.getText().toString().trim();
                String height = txt_height.getText().toString().trim();
                String weight = txt_weight.getText().toString().trim();

                profileclass =  new ProfileClass(name, surname,email,height,weight);
                myRef.setValue(profileclass);


            }


        });
    }

    public void openUpdateProfile() {
        Intent intent = new Intent(this, UpdateProfile.class);
        startActivity(intent);
    }


            }


