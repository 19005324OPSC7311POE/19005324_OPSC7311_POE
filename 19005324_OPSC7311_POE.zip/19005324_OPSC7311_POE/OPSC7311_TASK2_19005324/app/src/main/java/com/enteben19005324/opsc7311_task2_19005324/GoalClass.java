package com.enteben19005324.opsc7311_task2_19005324;

public class GoalClass
{
    String exercise;
    String goalweight;

    public GoalClass(String exercise, String goalweight) {
        this.exercise = exercise;
        this.goalweight = goalweight;
    }

    public String getExercise() {
        return exercise;
    }

    public void setExercise(String exercise) {
        this.exercise = exercise;
    }

    public String getGoalweight() {
        return goalweight;
    }

    public void setGoalweight(String goalweight) {
        this.goalweight = goalweight;
    }
}
