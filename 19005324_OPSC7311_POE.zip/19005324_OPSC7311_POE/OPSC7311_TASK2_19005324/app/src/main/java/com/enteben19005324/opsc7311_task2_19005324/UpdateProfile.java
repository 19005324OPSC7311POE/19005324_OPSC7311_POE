package com.enteben19005324.opsc7311_task2_19005324;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class UpdateProfile extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_profile);
    }
}